<?php
/* Smarty version 3.1.33, created on 2018-09-28 08:35:31
  from 'C:\@CloudDrives\Dropbox\@Messiah\@courses\cis291\291WebExamples\public_html\templates\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5bae2013d7d046_08401825',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ab04fd172ba6e162245e0d651f011d686a18f6ea' => 
    array (
      0 => 'C:\\@CloudDrives\\Dropbox\\@Messiah\\@courses\\cis291\\291WebExamples\\public_html\\templates\\home.tpl',
      1 => 1538137699,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bae2013d7d046_08401825 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
</head>
<body>
    <h1>Welcome to <?php echo $_smarty_tpl->tpl_vars['variable_name']->value;?>
</h1>
    <p>This is an example of how a basic html page can be turned into a template
       and populated by smarty.
    </p>
</body>
</html><?php }
}
