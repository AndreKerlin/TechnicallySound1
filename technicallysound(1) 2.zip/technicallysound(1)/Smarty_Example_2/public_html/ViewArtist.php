<?php

require_once "../private_html/config.inc.php";

$smarty->display('ViewArtist.tpl');