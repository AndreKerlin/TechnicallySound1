<?php
/**
 * Created by PhpStorm.
 * User: Andre
 * Date: 11/6/18
 * Time: 4:08 PM
 */

//$Smarty = new Smarty;

require_once "../private_html/config.inc.php";
//{include file = "templates/FeaturedArtist.tpl"}

$smarty->display('FeaturedArtists.tpl');